package com.example.alkewallet_kotlin

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.alkewallet_kotlin.databinding.ActivityProfileBinding
import com.example.alkewallet_kotlin.model.AlkeObject

class Profile : AppCompatActivity() {

    private lateinit var binding: ActivityProfileBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityProfileBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val nombre = "${AlkeObject.nombreUsuario}"
        val apellido = "${AlkeObject.apellidoUsuario}"
        val correo = "${AlkeObject.correoUsuario}"
        val origen = "${AlkeObject.origen}"

        binding.etNombre.setText(nombre)
        binding.etApellido.setText(apellido)
        binding.etCorreo2.setText(correo)


        Log.d("Alke_Debug_Profile", "Nombre guardado: ${AlkeObject.nombreUsuario}")
        Log.d("Alke_Debug_Profile", "Apellido guardado: ${AlkeObject.apellidoUsuario}")
        Log.d("Alke_Debug_Profile", "Correo guardado: ${AlkeObject.correoUsuario}")
        Log.d("Alke_Debug_Profile", "origen guardado: ${AlkeObject.origen}")

        //setContentView(R.layout.activity_profile)

        val btnBack = findViewById<ImageView>(R.id.btnBack)
        val btnCerrar = findViewById<Button>(R.id.btnCerrarSesion)

        btnBack.setOnClickListener {
            val intent = Intent(this, Home::class.java)
            startActivity(intent)
            finish()
        }




        binding.btnGuardarPerfil.setOnClickListener {
            val patronLetras = Regex("^[a-zA-ZáéíóúÁÉÍÓÚñÑ ]+$")

            val nombreIngresado = binding.etNombre.text.toString().trim()
            val apellidoIngresado = binding.etApellido.text.toString().trim()
            val clave3Ingresado = binding.etClave3.text.toString().trim()

            if (nombreIngresado.isEmpty()) {
                binding.etNombre.error = "Ingresa tu nombre"
            } else if (!nombreIngresado.matches(patronLetras)) {
                binding.etNombre.error = "El nombre sólo debe contener letras"
            } else if (apellidoIngresado.isEmpty()) {
                binding.etApellido.error = "Ingresa tu apellido"
            } else if (!apellidoIngresado.matches(patronLetras)) {
                binding.etApellido.error = "El apellido sólo debe contener letras"
            } else if (clave3Ingresado.isEmpty()) {
                binding.etClave3.error = "Ingresa tu clave"
            } else {

                AlkeObject.nombreUsuario = nombreIngresado
                AlkeObject.apellidoUsuario = apellidoIngresado
                AlkeObject.origen = "Profile"

                Toast.makeText(this, "Perfil actualizado con éxito $nombreIngresado", Toast.LENGTH_SHORT).show()

                val intent = Intent(this, Home::class.java)
                startActivity(intent)
                finish()
            }
        }

        btnCerrar.setOnClickListener {
            finish()
        }
    }
}
package com.example.alkewallet_kotlin

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.alkewallet_kotlin.databinding.ActivityRequestMoneyBinding
import com.example.alkewallet_kotlin.controller.AlkeController
import com.example.alkewallet_kotlin.model.AlkeObject
import com.example.alkewallet_kotlin.model.TransaccionModel
import com.example.alkewallet_kotlin.network.RetrofitCliente
import kotlinx.coroutines.launch


class RequestMoney : AppCompatActivity() {

    private lateinit var binding: ActivityRequestMoneyBinding
    private lateinit var controller: AlkeController

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityRequestMoneyBinding.inflate(layoutInflater)
        setContentView(binding.root)

        controller = AlkeController()

        binding.btnIngresarDinero.setOnClickListener {
            val montoIngresado = binding.etMontoEnviar.text.toString().toLongOrNull()
            val motivoIngresar = binding.etMotivo2.text.toString()
            val userIdActual = AlkeObject.idUsuario

            if (montoIngresado != null && montoIngresado > 0) {
                lifecycleScope.launch {
                    try {
                        val usuario = RetrofitCliente.usuarioId.obtenerUsuarioId(userIdActual)
                        val nuevoSaldo = usuario.saldo + montoIngresado

                        val actualizacionSaldo = mapOf("saldo" to nuevoSaldo)
                        val respuestaSaldo = RetrofitCliente.usuarioId.guardarUsuarioId(userIdActual, actualizacionSaldo)

                        if (respuestaSaldo.isSuccessful) {

                            val nuevaTrx = TransaccionModel(
                                id = 0, // El ID lo genera MockAPI
                                idUsuario = userIdActual,
                                operacion = "Ingreso",
                                monto = montoIngresado,
                                motivo = motivoIngresar
                            )

                            val responseTrx = RetrofitCliente.transaccionApi.crearTrx(nuevaTrx)

                            if (responseTrx.isSuccessful) {
                                controller.IngresaMonto(montoIngresado.toLong(), "Ingresado por: $motivoIngresar")

                                Toast.makeText(this@RequestMoney, "Operación exitosa", Toast.LENGTH_SHORT).show()
                                startActivity(Intent(this@RequestMoney, Home::class.java))
                                finish()
                            }
                        }
                    } catch (e: Exception) {
                        Toast.makeText(this@RequestMoney, "Error: ${e.message}", Toast.LENGTH_LONG).show()
                    }
                }
            } else {
                Toast.makeText(this, "Ingrese un monto válido", Toast.LENGTH_SHORT).show()
            }

            /*
            val montoEnviar = binding.etMontoEnviar.getText().toString().toIntOrNull()
            val motivoIngresar = binding.etMotivo2.getText().toString()

            if (montoEnviar != null && montoEnviar > 0) {
                if (controller.IngresaMonto(montoEnviar, "Ingresado por: $motivoIngresar")) {
                    Toast.makeText(this, "Ingreso realizado con éxito", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Error al realizar el ingreso", Toast.LENGTH_SHORT).show()
                }
                val intent = Intent(this, Home::class.java)
                startActivity(intent)
                //finish()
            } else {
                Toast.makeText(this, "Ingrese un monto válido", Toast.LENGTH_SHORT).show()
            }*/
        }


        binding.imvIrHome2.setOnClickListener {
            val intent = Intent(this, Home::class.java)
            startActivity(intent)
            finish()
        }

    }
}
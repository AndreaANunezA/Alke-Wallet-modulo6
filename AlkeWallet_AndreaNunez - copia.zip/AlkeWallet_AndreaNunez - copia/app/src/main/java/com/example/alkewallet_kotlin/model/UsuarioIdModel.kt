package com.example.alkewallet_kotlin.model

data class UsuarioIdModel(
    val id: Int,
    val nombre:String,
    val apellido: String,
    val email: String,
    val clave: String,
    val saldo: Long
)

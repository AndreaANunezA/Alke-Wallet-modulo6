package com.example.alkewallet_kotlin

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import com.example.alkewallet_kotlin.databinding.ActivityHomeBinding
import com.example.alkewallet_kotlin.model.AlkeObject
import android.util.Log
import android.widget.Toast
import androidx.lifecycle.lifecycleScope
import com.example.alkewallet_kotlin.network.RetrofitCliente
import kotlinx.coroutines.launch

class Home : AppCompatActivity() {

    private lateinit var binding: ActivityHomeBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val usuario = "${AlkeObject.nombreUsuario} ${AlkeObject.apellidoUsuario}"
        val correo = "${AlkeObject.correoUsuario}"
        val origen = "${AlkeObject.origen}"

        Log.d("Alke_Debug_Home", "Nombre guardado: ${AlkeObject.nombreUsuario}")
        Log.d("Alke_Debug_Home", "Apellido guardado: ${AlkeObject.apellidoUsuario}")
        Log.d("Alke_Debug_Home", "Correo guardado: ${AlkeObject.correoUsuario}")
        Log.d("Alke_Debug_Home", "origen guardado: ${AlkeObject.origen}")


        binding.tvUsuario.text = "¡Hola, $usuario !"

        val btnEnviarSaldo = findViewById<Button>(R.id.btnEnviarSaldo)
        val btnIngresarSaldo = findViewById<Button>(R.id.btnIngresarSaldo)
        val imvPerfil = findViewById<ImageView>(R.id.imvPerfil)

        val listaInversa = AlkeObject.listaMovimientos.reversed()
        val stringBuilder = StringBuilder()

        for (item in listaInversa) {
            stringBuilder.append("Monto: $${item.monto} Saldo actual: $${item.saldo}\n")
            stringBuilder.append("${item.motivo}\n\n")
        }

        val saldoActual = AlkeObject.saldo
        binding.tvSaldo.text = "$ $saldoActual"


        btnEnviarSaldo.setOnClickListener {

            if(saldoActual > 0) {
                val intent = Intent(this, SendMoney::class.java)
                startActivity(intent)
                finish()
            } else
                Toast.makeText(this, "No tienes saldo suficiente", Toast.LENGTH_SHORT).show()
        }

        btnIngresarSaldo.setOnClickListener {
            val intent = Intent(this, RequestMoney::class.java)
            startActivity(intent)
            finish()
        }

        imvPerfil.setOnClickListener {
            val intent = Intent(this, Profile::class.java)
            startActivity(intent)
            finish()
        }

    }

    override fun onResume() {
        super.onResume()
        cargarTransacciones()
    }

    private fun cargarTransacciones() {
        lifecycleScope.launch {
            try {
                val response = RetrofitCliente.transaccionApi.obtenerTodasLasTrx()

                if (response.isSuccessful) {
                    val todasLasTrx = response.body() ?: emptyList()

                    val misTransacciones = todasLasTrx.filter { it.idUsuario == AlkeObject.idUsuario }

                    Log.d("DEBUG_TRX", "Total API: ${todasLasTrx.size} | Filtradas para usuario ${AlkeObject.idUsuario}: ${misTransacciones.size}")

                    val adapter = TransaccionAdapter(misTransacciones.reversed())
                    binding.rvTransacciones.adapter = adapter

                    if (misTransacciones.isEmpty()) {
                        Toast.makeText(this@Home, "Sin transacciones", Toast.LENGTH_SHORT).show()
                    }

                } else {
                    Log.e("API_ERROR", "Error: ${response.code()}")
                }
            } catch (e: Exception) {
                Log.e("NETWORK_ERROR", "Error de conexión: ${e.message}")
            }
        }
    }
}
package com.example.alkewallet_kotlin

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.alkewallet_kotlin.databinding.ActivityLoginBinding
import com.example.alkewallet_kotlin.databinding.ActivitySignupBinding
import com.example.alkewallet_kotlin.model.AlkeObject
import com.example.alkewallet_kotlin.network.RetrofitCliente
import com.example.alkewallet_kotlin.utils.toSha256
import kotlinx.coroutines.launch


private fun validaCorreo(correo: String): Boolean {
    return android.util.Patterns.EMAIL_ADDRESS.matcher(correo).matches()
}
class Login : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.imvIrLogSign.setOnClickListener {
            val intent = Intent(this, LoginSignup::class.java)
            startActivity(intent)
            finish()
        }


        binding.btnIngresar.setOnClickListener {
            val correoIngresado = binding.etCorreo.text.toString().trim()
            val claveIngresada = binding.etClave.text.toString().trim()

            if (correoIngresado.isEmpty()) {
                binding.etCorreo.error = "Ingresa un correo electrónico"
            } else if (!validaCorreo(correoIngresado)) {
                binding.etCorreo.error = "Ingresa un correo electrónico válido"
            } else if (claveIngresada.isEmpty()) {
                binding.etClave.error = "Ingresa la clave"
            } else {
                lifecycleScope.launch {
                    try {
                        val response = RetrofitCliente.usuarioId.obtenerUsuarios()

                        if (response.isSuccessful) {
                            val listaUsuarios = response.body()

                            val claveHasheada = claveIngresada.toSha256()

                            val usuarioEncontrado = listaUsuarios?.find { it.email == correoIngresado }

                            if (usuarioEncontrado != null) {
                                if (usuarioEncontrado.clave == claveHasheada) {
                                    AlkeObject.idUsuario = usuarioEncontrado.id
                                    AlkeObject.nombreUsuario = usuarioEncontrado.nombre
                                    AlkeObject.apellidoUsuario = usuarioEncontrado.apellido
                                    AlkeObject.correoUsuario = usuarioEncontrado.email
                                    AlkeObject.saldo = usuarioEncontrado.saldo
                                    AlkeObject.origen = "Login"

                                    Toast.makeText(this@Login, "Bienvenido ${usuarioEncontrado.nombre}", Toast.LENGTH_SHORT).show()

                                    val intent = Intent(this@Login, Home::class.java)
                                    startActivity(intent)
                                    finish()

                                } else {
                                    Toast.makeText(this@Login, "Contraseña incorrecta", Toast.LENGTH_SHORT).show()
                                    binding.etClave.setText("")
                                    binding.etClave.requestFocus()
                                }
                            } else {
                                Toast.makeText(this@Login, "Usuario no encontrado. Regístrate.", Toast.LENGTH_LONG).show()
                                val intent = Intent(this@Login, Signup::class.java)
                                startActivity(intent)
                                finish()
                            }
                        } else {
                            Toast.makeText(this@Login, "Error en el servidor: ${response.code()}", Toast.LENGTH_SHORT).show()
                        }
                    } catch (e: Exception) {
                        Toast.makeText(this@Login, "Error de conexión: ${e.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
       /*binding.btnIngresar.setOnClickListener {
            val correoIngresado = binding.etCorreo.text.toString().trim()
            val claveIngresada = binding.etClave.text.toString().trim()

            if (correoIngresado.isEmpty()) {
                binding.etCorreo.error = "Ingresa un correo electrónico"
            } else if (!validaCorreo(correoIngresado)) {
                binding.etCorreo.error = "Ingresa un correo electrónico válido"
            } else if (claveIngresada.isEmpty()) {
                binding.etClave.error = "Ingresa la clave"
            }else {

                AlkeObject.correoUsuario = correoIngresado
                AlkeObject.origen = "Login"



                val intent = Intent(this, Home::class.java)
                startActivity(intent)
                finish()
            }

        }*/

    }
}
package com.example.alkewallet_kotlin.model

import com.example.alkewallet_kotlin.model.AlkeObject.listaMovimientos
import com.example.alkewallet_kotlin.model.AlkeObject.saldo

class AlkeModel {
    fun IngresaMonto(monto: Long, motivo: String): Boolean {
        saldo += monto
        listaMovimientos.add(Transaccion(monto, saldo, motivo))
        return true
    }

    fun EnviaMonto(monto: Long, motivo: String): Boolean {
        saldo -= monto
        listaMovimientos.add(Transaccion(monto, saldo, motivo))
        return true
    }
}

package com.example.alkewallet_kotlin.network
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object RetrofitCliente {
    private const val BASE_URL_ALKE = "https://69dd74f184f912a264051016.mockapi.io/api/AlkeWallet/"

    val usuarioId: UsuarioIdApiService by lazy{
        Retrofit.Builder()
            .baseUrl(BASE_URL_ALKE)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(UsuarioIdApiService::class.java)
    }

    val transaccionApi: TransaccionApiService by lazy{
        Retrofit.Builder()
            .baseUrl(BASE_URL_ALKE)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(TransaccionApiService::class.java)
    }
}
package com.example.alkewallet_kotlin

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.alkewallet_kotlin.databinding.ActivitySendMoneyBinding
import com.example.alkewallet_kotlin.controller.AlkeController
import com.example.alkewallet_kotlin.model.AlkeObject
import com.example.alkewallet_kotlin.model.TransaccionModel
import com.example.alkewallet_kotlin.network.RetrofitCliente
import kotlinx.coroutines.launch


class SendMoney : AppCompatActivity() {

    private lateinit var binding: ActivitySendMoneyBinding
    private lateinit var controller: AlkeController

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivitySendMoneyBinding.inflate(layoutInflater)
        setContentView(binding.root)

        controller = AlkeController()

        binding.btnEnviar.setOnClickListener {
            val montoEnviar = binding.etMontoEnviar.text.toString().toLongOrNull()
            val motivoEnviar = binding.etMotivo.text.toString()
            val userIdActual = AlkeObject.idUsuario

            if (montoEnviar != null && montoEnviar > 0) {
                lifecycleScope.launch {
                    try {
                        val usuario = RetrofitCliente.usuarioId.obtenerUsuarioId(userIdActual)
                        val nuevoSaldo = usuario.saldo - montoEnviar

                        val actualizacionSaldo = mapOf("saldo" to nuevoSaldo)
                        val respuestaSaldo = RetrofitCliente.usuarioId.guardarUsuarioId(userIdActual, actualizacionSaldo)

                        if (respuestaSaldo.isSuccessful) {

                            val nuevaTrx = TransaccionModel(
                                id = 0, // El ID lo genera MockAPI
                                idUsuario = userIdActual,
                                operacion = "Envío",
                                monto = montoEnviar,
                                motivo = motivoEnviar
                            )

                            val responseTrx = RetrofitCliente.transaccionApi.crearTrx(nuevaTrx)

                            if (responseTrx.isSuccessful) {
                                controller.EnviaMonto(montoEnviar.toLong(), "Enviado por: $motivoEnviar")

                                Toast.makeText(this@SendMoney, "Operación exitosa", Toast.LENGTH_SHORT).show()
                                startActivity(Intent(this@SendMoney, Home::class.java))
                                finish()
                            }
                        }
                    } catch (e: Exception) {
                        Toast.makeText(this@SendMoney, "Error: ${e.message}", Toast.LENGTH_LONG).show()
                    }
                }
            } else {
                Toast.makeText(this, "Ingrese un monto válido", Toast.LENGTH_SHORT).show()
            }
        }

        binding.imvHome.setOnClickListener {
            val intent = Intent(this, Home::class.java)
            startActivity(intent)
            finish()
        }

    }
}
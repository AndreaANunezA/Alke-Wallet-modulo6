package com.example.alkewallet_kotlin
//package com.example.alkewallet_kotlin.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.alkewallet_kotlin.databinding.ItemTransaccionBinding
import com.example.alkewallet_kotlin.model.TransaccionModel

class TransaccionAdapter(private val transacciones: List<TransaccionModel>) :
    RecyclerView.Adapter<TransaccionAdapter.TransaccionViewHolder>() {

    class TransaccionViewHolder(val binding: ItemTransaccionBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TransaccionViewHolder {
        val binding =
            ItemTransaccionBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return TransaccionViewHolder(binding)
    }

    override fun onBindViewHolder(holder: TransaccionViewHolder, position: Int) {
        val item = transacciones[position]
        holder.binding.apply {

            if (item.operacion.lowercase() == "ingreso") {
                ivTipoIcono.setImageResource(R.drawable.ic_ingreso_flecha) // Flecha arriba
                ivTipoIcono.setBackgroundResource(R.drawable.bg_circulo_ingreso) // Círculo Verde
            } else {
                ivTipoIcono.setImageResource(R.drawable.ic_envio_flecha) // Flecha abajo
                ivTipoIcono.setBackgroundResource(R.drawable.bg_circulo_envio) // Círculo Rojo
            }

            tvMotivoItem.text = item.motivo
            tvOperacionItem.text = item.operacion
            tvMontoItem.text = "$${item.monto}"

        }
    }


    override fun getItemCount(): Int {
        return transacciones.size
    }
}

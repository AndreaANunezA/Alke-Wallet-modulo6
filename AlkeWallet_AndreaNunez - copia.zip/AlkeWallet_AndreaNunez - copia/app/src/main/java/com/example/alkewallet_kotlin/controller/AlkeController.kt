package com.example.alkewallet_kotlin.controller
import com.example.alkewallet_kotlin.model.AlkeModel

class AlkeController {
    private val model : AlkeModel

    init {
        model = AlkeModel()
    }
    fun IngresaMonto(monto: Long, motivo: String): Boolean {
        return model.IngresaMonto(monto, motivo)
    }

    fun EnviaMonto(monto: Long, motivo: String): Boolean {
        return model.EnviaMonto(monto, motivo)
    }

}
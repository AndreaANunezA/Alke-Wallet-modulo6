package com.example.alkewallet_kotlin

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.alkewallet_kotlin.databinding.ActivitySignupBinding
import com.example.alkewallet_kotlin.model.AlkeObject
import android.content.SharedPreferences
import androidx.lifecycle.lifecycleScope
import com.example.alkewallet_kotlin.model.UsuarioIdModel
import com.example.alkewallet_kotlin.network.RetrofitCliente
import kotlinx.coroutines.launch
import com.example.alkewallet_kotlin.utils.toSha256

private fun validaCorreo(correo: String): Boolean {
    return android.util.Patterns.EMAIL_ADDRESS.matcher(correo).matches()
}
class Signup : AppCompatActivity() {

    private lateinit var binding: ActivitySignupBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivitySignupBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.imvIrLogSign2.setOnClickListener {
            val intent = Intent(this, LoginSignup::class.java)
            startActivity(intent)
            finish()
        }

        binding.btnCrear.setOnClickListener {

            val patronLetras = Regex("^[a-zA-ZáéíóúÁÉÍÓÚñÑ ]+$")

            val nombreIngresado = binding.etNombre.text.toString().trim()
            val apellidoIngresado = binding.etApellido.text.toString().trim()
            val correo2Ingresado = binding.etCorreo2.text.toString().trim()
            val clave2Ingresado = binding.etClave2.text.toString().trim()
            val confirmaClaveIngresado = binding.etConfirmaClave.text.toString().trim()

            if (nombreIngresado.isEmpty()) {
                binding.etNombre.error = "Ingresa tu nombre"
            } else if (!nombreIngresado.matches(patronLetras)) {
                binding.etNombre.error = "El nombre sólo debe contener letras"
            } else if (apellidoIngresado.isEmpty()) {
                binding.etApellido.error = "Ingresa tu apellido"
            } else if (!apellidoIngresado.matches(patronLetras)) {
                binding.etApellido.error = "El apellido sólo debe contener letras"
            } else if (correo2Ingresado.isEmpty()) {
                binding.etCorreo2.error = "Ingresa un correo electrónico"
            } else if (!validaCorreo(correo2Ingresado)) {
                binding.etCorreo2.error = "Ingresa un correo electrónico válido"
            } else if (clave2Ingresado.isEmpty()) {
                binding.etClave2.error = "Ingresa tu clave"
            } else if (confirmaClaveIngresado.isEmpty()) {
                binding.etConfirmaClave.error = "Confirma tu clave"
            } else if (clave2Ingresado != confirmaClaveIngresado) {
                binding.etConfirmaClave.error = "Las contraseñas no coinciden"
                binding.etConfirmaClave.setText("")
            } else {
                // Guardar datos locales y navegar a Home
                AlkeObject.nombreUsuario = nombreIngresado
                AlkeObject.apellidoUsuario = apellidoIngresado
                AlkeObject.correoUsuario = correo2Ingresado
                AlkeObject.origen = "Signup"

                lifecycleScope.launch {
                    try {
                        val responseGet = RetrofitCliente.usuarioId.obtenerUsuarios()

                        if (responseGet.isSuccessful) {
                            val usuario = responseGet.body()

                            val usuarioExistente = usuario?.find { it.email == correo2Ingresado }

                            if (usuarioExistente != null) {
                                AlkeObject.idUsuario = usuarioExistente.id
                                AlkeObject.saldo = usuarioExistente.saldo

                                Toast.makeText(this@Signup, "El usuario ya existe. Inicia sesión.", Toast.LENGTH_LONG).show()
                                val intent = Intent(this@Signup, Login::class.java)
                                startActivity(intent)
                                finish()
                            } else {
                                // Encripta la clave
                                val claveEncriptada = clave2Ingresado.toSha256()

                                val nuevoUsuario = UsuarioIdModel(
                                    id = 0, // genera el ID automáticamente
                                    nombre = nombreIngresado,
                                    apellido = apellidoIngresado,
                                    email = correo2Ingresado,
                                    clave = claveEncriptada,
                                    saldo = 0
                                )

                                val responsePost = RetrofitCliente.usuarioId.crearUsuario(nuevoUsuario)

                                if (responsePost.isSuccessful) {

                                    val usuarioCreado = responsePost.body()

                                    if (usuarioCreado != null) {
                                        val idAsignado = usuarioCreado.id

                                        AlkeObject.idUsuario = idAsignado
                                    }
                                    Toast.makeText(this@Signup,"Cuenta creada con éxito",Toast.LENGTH_SHORT
                                    ).show()
                                }

                                val intent = Intent(this@Signup, Home::class.java)
                                startActivity(intent)
                                finish()
                                }
                            }

                    } catch (e: Exception) {
                        Toast.makeText(this@Signup, "Error de conexión: ${e.message}", Toast.LENGTH_SHORT).show()
                    }
                }

                /*Toast.makeText(this, "Bienvenido/a $nombreIngresado", Toast.LENGTH_SHORT).show()

                val intent = Intent(this, Home::class.java)
                startActivity(intent)
                finish()*/
            }
        }
    }
}
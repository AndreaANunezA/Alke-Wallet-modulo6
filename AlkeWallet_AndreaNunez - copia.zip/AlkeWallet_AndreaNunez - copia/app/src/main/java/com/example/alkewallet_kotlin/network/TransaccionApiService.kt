package com.example.alkewallet_kotlin.network

import com.example.alkewallet_kotlin.model.TransaccionModel
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST

interface TransaccionApiService {
    @POST("transacciones")
    suspend fun crearTrx(@Body nuevoTrx: TransaccionModel): Response<TransaccionModel>

    @GET("transacciones")
    suspend fun obtenerTodasLasTrx(): Response<List<TransaccionModel>>
}
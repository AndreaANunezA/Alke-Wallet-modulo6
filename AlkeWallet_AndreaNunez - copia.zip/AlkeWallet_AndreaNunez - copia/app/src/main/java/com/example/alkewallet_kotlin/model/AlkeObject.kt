package com.example.alkewallet_kotlin.model
//import androidx.compose.ui.graphics.drawscope.Stroke
data class Transaccion(
    val monto: Long,
    val saldo: Long,
    val motivo: String
)
object AlkeObject {
    var nombreUsuario: String = ""
    var apellidoUsuario: String = ""
    var correoUsuario: String = ""

    var origen: String = ""

    val listaMovimientos = mutableListOf<Transaccion>()

    var saldo: Long = 0

    var idUsuario: Int = 0
}

package com.example.alkewallet_kotlin.model

data class TransaccionModel(
    val id: Int,
    val idUsuario: Int,
    val operacion: String,
    val monto: Long,
    val motivo: String
)

package com.example.alkewallet_kotlin.network

import com.example.alkewallet_kotlin.model.UsuarioIdModel
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Path

interface UsuarioIdApiService {
    @GET("usuarios")
    suspend fun obtenerUsuarios(): Response<List<UsuarioIdModel>>

    @GET("usuarios/{id}")
    suspend fun obtenerUsuarioId(@Path("id") userId: Int): UsuarioIdModel

    @POST("usuarios")
    suspend fun crearUsuario(@Body nuevoUsuario: UsuarioIdModel): Response<UsuarioIdModel>

    @PUT("usuarios/{id}")
    suspend fun guardarUsuarioId(
        @Path("id") id: Int,
        @Body campos: Map<String, @JvmSuppressWildcards Any>
    ): Response<UsuarioIdModel>
}